# Softline-Cinepolis

## Prerequisites

Please refer to [documentation/Prerequisites](documentation/Prerequisites.md).

## Usage

Please refer to [documentation/Usage](documentation/Usage.md).

## Solutions

### Monitoring Dashboard

Please refer to [documentation/Monitoring Dashboard](documentation/Monitoring-Dashboard.md).

## Notes